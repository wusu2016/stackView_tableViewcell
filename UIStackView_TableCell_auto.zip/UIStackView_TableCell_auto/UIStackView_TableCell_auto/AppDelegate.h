//
//  AppDelegate.h
//  UIStackView_TableCell_auto
//
//  Created by Wusu on 2021/5/31.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

